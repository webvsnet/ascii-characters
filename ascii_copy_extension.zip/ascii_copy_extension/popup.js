document.addEventListener('DOMContentLoaded', () => {
    const grid = document.getElementById('grid');
    const searchInput = document.getElementById('search');
    const toast = document.getElementById('toast');

    // Extended ASCII range 128-255
    const characters = [];
    for (let i = 128; i <= 255; i++) {
        // Windows-1252 is cleaner for these ranges in typical web usage, or just String.fromCharCode(i)
        // String.fromCharCode with isolate code points is usually what's meant by "Extended ASCII" in basic context
        // However, explicit encoding logic might be better if we want specific Code Page 437 or Windows-1252 symbols.
        // For general web "Extended ASCII", raw code points 128-255 are often control chars in Unicode (C1 Controls).
        // What users typically want is Windows-1252 or CP437 visual representation.
        // Let's stick to Windows-1252 (ANSI) which is the most common web "Extended ASCII" meaning.

        // Actually, let's try to be smart. Code points 128-159 in standard Unicode are C1 controls and don't render.
        // Users likely want the display characters. 
        // We will render them as Windows-1252 which maps 128-159 to useful chars (like euro, dagger, etc).

        // We'll create a decoder for Windows-1252
        const decoder = new TextDecoder('windows-1252');
        const uint8 = new Uint8Array([i]);
        const char = decoder.decode(uint8);

        characters.push({
            code: i,
            char: char
        });
    }

    function renderGrid(chars) {
        grid.innerHTML = '';

        if (chars.length === 0) {
            grid.innerHTML = '<div class="no-results">No characters found</div>';
            return;
        }

        chars.forEach(item => {
            const card = document.createElement('div');
            card.className = 'char-card';
            // We'll visually show the code, and the character.
            // Accessibility label
            card.setAttribute('aria-label', `Copy character ${item.char}, code ${item.code}`);
            card.setAttribute('role', 'button');

            card.innerHTML = `
        <span class="char-symbol">${item.char}</span>
        <span class="char-code">${item.code}</span>
      `;

            card.addEventListener('click', () => copyToClipboard(item.char));
            grid.appendChild(card);
        });
    }

    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            showToast();
        }).catch(err => {
            console.error('Failed to copy: ', err);
        });
    }

    let toastTimeout;
    function showToast() {
        toast.classList.add('show');
        clearTimeout(toastTimeout);
        toastTimeout = setTimeout(() => {
            toast.classList.remove('show');
        }, 2000);
    }

    function filterChars(query) {
        const lowerQuery = query.toLowerCase();
        const normalize = (str) => str.normalize('NFD').replace(/[\u0300-\u036f]/g, "").toLowerCase();
        const normalizedQuery = normalize(lowerQuery);

        return characters.filter(item => {
            // Match by code
            if (item.code.toString().includes(lowerQuery)) return true;

            // Match by exact char
            if (item.char.toLowerCase().includes(lowerQuery)) return true;

            // Match by base char (smart search)
            // If the query is "e", we want to match "é" etc.
            // We check if the normalized item char contains the normalized query
            // This allows "e" to find "é", "è", etc.
            if (normalize(item.char).includes(normalizedQuery)) return true;

            return false;
        });
    }

    searchInput.addEventListener('input', (e) => {
        const filtered = filterChars(e.target.value);
        renderGrid(filtered);
    });

    // Initial render
    renderGrid(characters);
});
